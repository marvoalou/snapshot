### website & how to run

https://github.com/facebookresearch/clevr-dataset-gen

### blender version

https://www.blender.org/download/releases/2-79/

### problems i met

should use blender 2.79

but my cuda version >= 11(NVIDIA), cannot use my GPU accelerate
