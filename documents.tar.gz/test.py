c = c1 - cout

v = 

t = 60

f = 0.0027289

c1 = 

cout = 